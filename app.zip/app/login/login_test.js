'use strict';

describe('myApp.login module', function() {

  beforeEach(module('myApp.login'));

  describe('login controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view1Ctrl = $controller('LoginCtrl');
      expect(view1Ctrl).toBeDefined();
    }));

  });
});